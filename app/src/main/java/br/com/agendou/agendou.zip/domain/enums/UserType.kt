package br.com.agendou.domain.enums

enum class UserType {
    CLIENT,
    PROFESSIONAL,
}