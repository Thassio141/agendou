package br.com.agendou.domain.enums

enum class AppointmentStatus {
    SCHEDULED,
    COMPLETED,
    CANCELED,
}